# Drift

Instagram as a feed: photos, carousels and **reels (as pictures; there is no video playback)**. Dark purple look, Inter font.
Drift runs the real desktop instagram.com in a hidden browser, reads the pictures it loads, and draws its own feed.

## Using it

- **Navbar**: a small floating pill, 10dp above the bottom: Home, Saved and three dots (Settings).
  - **Hold the three dots and drag** to a side or corner; the spots light up, let go over one. It turns vertical on the sides.
  - **Tap Home / Saved** to switch. **Hold Home** for a drop-up: Home, All profiles, or one saved profile.
    **Hold Saved**: All posts, or one of your Saved groups. Each tab remembers its choice.
- **All profiles** merges every saved profile, newest first; the hidden browser visits each profile to load it.
- **Hold a post**: Save post (on Instagram) / Unsave, Go to @profile, Send to chat (only with Chat on), Save to device
  (Pictures/Drift), Open in browser.
- **Profile view** (Go to @profile): small avatar, @name, icon-only Save profile button, tabs Posts / Reels / Tagged /
  Followers / Following. Tap a picture to open it in the Browser, hold it for the post menu, tap a name to open that profile.
- **Settings**: navbar buttons, Photos / Reels, Hide ads, Chat, add saved profiles in bulk, **Browser** (real instagram.com,
  where you sign in), Reset feed, Sign out.

## What Drift asks Instagram for itself

Everything else is just reading what the page loads. Drift makes its own requests (from inside the page, with your login)
only for: your Saved groups list, Save/Unsave post, and, with **Chat** on, your chat list and Send to chat (it sends the
post's link). These are Instagram's unofficial web endpoints, so they can change or stop working. Chat is off by default.

## Build

Open this folder in Android Studio (Ladybug or newer), let Gradle sync, press Run.

## Where things live

- `InstagramViewModel.kt`: the hidden browser, page tracking, per-page data, All-profiles crawler, groups, actions, chat.
- `data/InstagramData.kt`: JSON parser (photos, reels, owner, date, avatars). `data/InstagramStore.kt`: saved profiles,
  groups, Home/Saved choices. `data/DriftSettings.kt`: switches and navbar dock.
- `ui/BrowseScreen.kt` (main screen), `NavBar.kt`, `Menus.kt` (drop-ups, hold menu, Send sheet), `FeedViews.kt`,
  `ProfileScreen.kt`, `SettingsScreen.kt`, `AppRoot.kt`, `Common.kt`, `Icons.kt`, `theme/Theme.kt`.
