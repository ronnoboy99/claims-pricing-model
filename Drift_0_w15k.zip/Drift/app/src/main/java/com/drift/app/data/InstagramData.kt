package com.drift.app.data

import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.net.HttpURLConnection
import java.net.URL

enum class IgKind { PHOTO, REEL }

/** One picture of a post. A reel is shown by its poster frame; there is no video playback anywhere in Drift. */
data class IgMedia(
    val id: String,
    val post: String,
    val index: Int,        // position inside its post (0 for single items)
    val count: Int,        // items in the post (>1 means carousel)
    val kind: IgKind,
    val url: String,       // the picture (for a reel, its poster frame)
    val owner: String,     // username of the account that posted it ("" if the data didn't say)
    val ts: Long,          // posted-at, seconds since 1970 (0 if unknown); used to merge several profiles by date
    val w: Int,
    val h: Int,
)

/** What one piece of page JSON held: the pictures, plus profile pictures seen next to usernames. */
class IgParsed(val media: List<IgMedia>, val avatars: Map<String, String>)

/** "https://www.instagram.com/artistic.arcade/", "@artistic.arcade" or "artistic.arcade" -> "artistic.arcade". */
fun parseInstagramProfile(input: String): String? {
    var s = input.trim().substringBefore(',').substringBefore(' ')
    s = s.substringBefore('?').substringBefore('#')
    s = s.removePrefix("https://").removePrefix("http://")
    if (s.contains("instagram.com/")) s = s.substringAfter("instagram.com/")
    s = s.trim('/').substringBefore('/').removePrefix("@").lowercase()
    val reserved = setOf(
        "p", "reel", "reels", "tv", "stories", "explore", "accounts", "direct", "challenge", "legal", "about",
        "web", "developer", "session", "oauth", "api", "graphql", "static", "privacy", "emails", "ajax",
    )
    return s.takeIf { it !in reserved && Regex("[a-z0-9._]{1,30}").matches(it) }
}

/** Downloads images from Instagram's CDN (those links need no login). */
object IgImages {
    fun fetch(url: String, userAgent: String): ByteArray {
        var c: HttpURLConnection? = null
        try {
            c = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 10_000
                readTimeout = 30_000
                setRequestProperty("User-Agent", userAgent)
            }
            if (c.responseCode !in 200..299) error("Download failed (${c.responseCode})")
            return c.inputStream.readBytes()
        } finally {
            c?.disconnect()
        }
    }
}

/**
 * Finds photos and reels in the JSON that Instagram's own page loads (feed pages, post pages, data embedded
 * in the page). Handles both the newer shape (image_versions2 / video_versions / carousel_media) and the older one
 * (display_url / video_url / edge_sidecar_to_children). When [only] is set, items that belong to a different account
 * are ignored.
 */
object IgCapture {

    fun parse(text: String, only: String?, hideAds: Boolean = true): IgParsed {
        val root = runCatching { JSONTokener(text).nextValue() }.getOrNull() ?: return IgParsed(emptyList(), emptyMap())
        val out = LinkedHashMap<String, IgMedia>()
        val avatars = HashMap<String, String>()
        walk(root, only, hideAds, out, avatars, 0)
        return IgParsed(out.values.toList(), avatars)
    }

    private fun walk(
        n: Any?, only: String?, hideAds: Boolean,
        out: MutableMap<String, IgMedia>, avatars: MutableMap<String, String>, depth: Int,
    ) {
        if (depth > 40) return
        when (n) {
            is JSONObject -> {
                avatar(n, avatars)
                if (!item(n, only, hideAds, out, avatars)) {
                    val keys = n.keys()
                    while (keys.hasNext()) walk(n.opt(keys.next()), only, hideAds, out, avatars, depth + 1)
                }
            }
            is JSONArray -> for (i in 0 until n.length()) walk(n.opt(i), only, hideAds, out, avatars, depth + 1)
        }
    }

    /** A user object (username next to profile_pic_url): remember the picture so profile views can show it. */
    private fun avatar(u: JSONObject?, avatars: MutableMap<String, String>) {
        if (u == null) return
        val name = u.optString("username")
        val pic = u.optString("profile_pic_url")
        if (name.isNotEmpty() && pic.isNotEmpty()) avatars[name.lowercase()] = pic
    }

    private class Raw(val url: String, val w: Int, val h: Int, val kind: IgKind)

    /** True when [o] is a post (so the caller should not look inside it). */
    private fun item(
        o: JSONObject, only: String?, hideAds: Boolean,
        out: MutableMap<String, IgMedia>, avatars: MutableMap<String, String>,
    ): Boolean {
        val code = o.optString("code").ifEmpty { o.optString("shortcode") }
        if (code.isEmpty()) return false
        val hasMedia = o.has("image_versions2") || o.has("carousel_media") ||
            o.has("display_url") || o.has("edge_sidecar_to_children")
        if (!hasMedia) return false

        // Leave out sponsored posts (they only appear in lists of other people's posts, never on a profile).
        if (hideAds && only == null && isAd(o)) return true

        val ownerObj = o.optJSONObject("user") ?: o.optJSONObject("owner")
        avatar(ownerObj, avatars)
        val owner = ownerObj?.optString("username").orEmpty()
        if (only != null && owner.isNotEmpty() && !owner.equals(only, ignoreCase = true)) return true

        val found = ArrayList<Raw>()
        val carousel = o.optJSONArray("carousel_media")
        val sidecar = o.optJSONObject("edge_sidecar_to_children")?.optJSONArray("edges")
        when {
            carousel != null -> for (i in 0 until carousel.length()) media(carousel.optJSONObject(i), o)?.let(found::add)
            sidecar != null -> for (i in 0 until sidecar.length()) {
                media(sidecar.optJSONObject(i)?.optJSONObject("node"), o)?.let(found::add)
            }
            else -> media(o, o)?.let(found::add)
        }
        val ts = o.optLong("taken_at").takeIf { it > 0 } ?: o.optLong("taken_at_timestamp")
        val who = owner.ifEmpty { only.orEmpty() }
        found.forEachIndexed { n, r ->
            out["${code}_$n"] = IgMedia("${code}_$n", code, n, found.size, r.kind, r.url, who, ts, r.w, r.h)
        }
        return true
    }

    /** Instagram marks a sponsored post in several ways, depending on the list it comes in. Any one of them is enough. */
    private fun isAd(o: JSONObject): Boolean {
        fun set(k: String): Boolean {
            val v = o.opt(k) ?: return false
            if (v == JSONObject.NULL) return false
            return v.toString().let { it.isNotEmpty() && it != "null" && it != "[]" && it != "{}" && it != "0" && it != "false" }
        }
        return set("ad_id") || set("ad_action") || set("ad_metadata") || set("injected") ||
            o.optBoolean("is_ad") || o.optBoolean("is_sponsored") || o.optString("product_type") == "ad"
    }

    /** One picture: a photo, or the poster frame of a reel. Null if nothing usable. */
    private fun media(m: JSONObject?, post: JSONObject): Raw? {
        if (m == null) return null
        var url = ""
        var w = 0
        var h = 0
        val cands = m.optJSONObject("image_versions2")?.optJSONArray("candidates")
        if (cands != null) {
            val best = (0 until cands.length()).mapNotNull { cands.optJSONObject(it) }
                .filter { it.optString("url").isNotEmpty() }
                .maxByOrNull { it.optInt("width") * it.optInt("height") }
            if (best != null) { url = best.getString("url"); w = best.optInt("width"); h = best.optInt("height") }
        }
        if (url.isEmpty()) {
            url = m.optString("display_url")
            val d = m.optJSONObject("dimensions")
            w = d?.optInt("width") ?: 0
            h = d?.optInt("height") ?: 0
        }
        if (url.isEmpty()) return null

        // Videos are not supported. A reel is kept (as its poster picture); any other video is left out.
        val isVideo = m.optInt("media_type") == 2 || m.optBoolean("is_video") ||
            (m.optJSONArray("video_versions")?.length() ?: 0) > 0
        if (!isVideo) return Raw(url, w, h, IgKind.PHOTO)
        return if (post.optString("product_type") == "clips") Raw(url, w, h, IgKind.REEL) else null
    }
}

/**
 * Instagram's post link code ("CxYz12AbCdE") is its numeric media id written in base 64; the id is what
 * instagram.com/api/v1/media/<id>/info/ needs. Null if the code has a character that doesn't belong.
 */
fun shortcodeToPk(code: String): String? {
    val alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
    val base = java.math.BigInteger.valueOf(64)
    var n = java.math.BigInteger.ZERO
    for (c in code.take(11)) {          // longer codes (private posts) carry a suffix after the id part
        val i = alphabet.indexOf(c)
        if (i < 0) return null
        n = n.multiply(base).add(java.math.BigInteger.valueOf(i.toLong()))
    }
    return n.toString()
}
