package com.drift.app.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drift.app.data.Dock
import com.drift.app.ui.theme.Accent
import com.drift.app.ui.theme.AccentBrush
import com.drift.app.ui.theme.Line
import com.drift.app.ui.theme.Panel
import com.drift.app.ui.theme.PanelHi
import com.drift.app.ui.theme.TextMuted
import kotlin.math.roundToInt

/** Where the navbar sits for each [Dock]. The bottom ones are 10dp above the bottom edge. */
fun dockPlacement(d: Dock): Pair<Alignment, PaddingValues> = when (d) {
    Dock.BOTTOM -> Alignment.BottomCenter to PaddingValues(bottom = 10.dp)
    Dock.BOTTOM_LEFT -> Alignment.BottomStart to PaddingValues(start = 12.dp, bottom = 10.dp)
    Dock.BOTTOM_RIGHT -> Alignment.BottomEnd to PaddingValues(end = 12.dp, bottom = 10.dp)
    Dock.LEFT -> Alignment.CenterStart to PaddingValues(start = 10.dp)
    Dock.RIGHT -> Alignment.CenterEnd to PaddingValues(end = 10.dp)
    Dock.TOP_LEFT -> Alignment.TopStart to PaddingValues(start = 12.dp, top = 28.dp)
    Dock.TOP_RIGHT -> Alignment.TopEnd to PaddingValues(end = 12.dp, top = 28.dp)
    Dock.TOP -> Alignment.TopCenter to PaddingValues(top = 28.dp)
}

/** Where the drop-up menus open: right beside the navbar, on the side that has room. */
fun menuPlacement(d: Dock): Pair<Alignment, PaddingValues> = when (d) {
    Dock.BOTTOM -> Alignment.BottomCenter to PaddingValues(bottom = 76.dp)
    Dock.BOTTOM_LEFT -> Alignment.BottomStart to PaddingValues(start = 12.dp, bottom = 76.dp)
    Dock.BOTTOM_RIGHT -> Alignment.BottomEnd to PaddingValues(end = 12.dp, bottom = 76.dp)
    Dock.LEFT -> Alignment.CenterStart to PaddingValues(start = 76.dp)
    Dock.RIGHT -> Alignment.CenterEnd to PaddingValues(end = 76.dp)
    Dock.TOP_LEFT -> Alignment.TopStart to PaddingValues(start = 12.dp, top = 94.dp)
    Dock.TOP_RIGHT -> Alignment.TopEnd to PaddingValues(end = 12.dp, top = 94.dp)
    Dock.TOP -> Alignment.TopCenter to PaddingValues(top = 94.dp)
}

fun isTopDock(d: Dock) = d == Dock.TOP || d == Dock.TOP_LEFT || d == Dock.TOP_RIGHT

/** Where each spot is, as a fraction of the screen (x, y). */
private fun anchor(d: Dock): Pair<Float, Float> = when (d) {
    Dock.BOTTOM -> 0.5f to 0.92f
    Dock.BOTTOM_LEFT -> 0.12f to 0.92f
    Dock.BOTTOM_RIGHT -> 0.88f to 0.92f
    Dock.LEFT -> 0.07f to 0.5f
    Dock.RIGHT -> 0.93f to 0.5f
    Dock.TOP_LEFT -> 0.12f to 0.07f
    Dock.TOP_RIGHT -> 0.88f to 0.07f
    Dock.TOP -> 0.5f to 0.07f
}

private fun nearestDock(finger: Offset, area: IntSize): Dock {
    if (area.width == 0 || area.height == 0) return Dock.BOTTOM
    return Dock.values().minByOrNull { d ->
        val (fx, fy) = anchor(d)
        val dx = finger.x - fx * area.width
        val dy = finger.y - fy * area.height
        dx * dx + dy * dy
    } ?: Dock.BOTTOM
}

/**
 * The small floating pill: Home, Saved and the three dots. Tap Home / Saved to switch, hold them for their drop-up.
 * Hold the three dots and drag: the spots light up, let go over one to dock the bar there (it turns vertical on the sides).
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun BoxScope.NavBar(
    dock: Dock,
    area: IntSize,
    onDock: (Dock) -> Unit,
    showHome: Boolean,
    showSaved: Boolean,
    homeActive: Boolean,
    savedActive: Boolean,
    onHome: () -> Unit,
    onSaved: () -> Unit,
    onHoldHome: () -> Unit,
    onHoldSaved: () -> Unit,
    onSettings: () -> Unit,
) {
    val haptic = LocalHapticFeedback.current
    val areaNow by rememberUpdatedState(area)
    val onDockNow by rememberUpdatedState(onDock)
    var dragging by remember { mutableStateOf(false) }
    var total by remember { mutableStateOf(Offset.Zero) }       // how far the finger has moved since the hold
    var pressAt by remember { mutableStateOf(Offset.Zero) }     // where the finger was when the hold started (screen)
    var dotsPos by remember { mutableStateOf(Offset.Zero) }
    var barPos by remember { mutableStateOf(Offset.Zero) }

    val vertical = dock == Dock.LEFT || dock == Dock.RIGHT
    val (alignment, pad) = dockPlacement(dock)
    val shape = RoundedCornerShape(28.dp)

    // The real bar stays put while you drag (so the drag math stays steady); a ghost of it follows the finger.
    val items: @Composable (Boolean) -> Unit = { live ->
        if (showHome) NavButton(AppIcons.Home, "Home", homeActive, onHome, onHoldHome)
        if (showSaved) NavButton(AppIcons.Saved, "Saved", savedActive, onSaved, onHoldSaved)
        Box(
            Modifier.then(if (vertical) Modifier.width(44.dp).height(28.dp) else Modifier.width(24.dp).height(44.dp))
                .then(
                    if (live) Modifier
                        .onGloballyPositioned { dotsPos = it.positionInRoot() }
                        .clickable(onClick = onSettings)
                        .pointerInput(Unit) {
                            detectDragGesturesAfterLongPress(
                                onDragStart = { off ->
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    total = Offset.Zero
                                    pressAt = dotsPos + off
                                    dragging = true
                                },
                                onDrag = { change, amount ->
                                    change.consume()
                                    total += amount
                                },
                                onDragEnd = {
                                    if (dragging) onDockNow(nearestDock(pressAt + total, areaNow))
                                    dragging = false
                                    total = Offset.Zero
                                },
                                onDragCancel = { dragging = false; total = Offset.Zero },
                            )
                        }
                    else Modifier
                ),
            contentAlignment = Alignment.Center,
        ) { Icon(AppIcons.More, "Settings", tint = TextMuted, modifier = Modifier.size(22.dp)) }
    }

    // The pill: 56dp thick, items spaced 2dp apart; horizontal on the bottom / top, vertical on the sides.
    val hBar = Modifier.height(56.dp).clip(shape).background(Panel).border(1.dp, Line, shape).padding(horizontal = 10.dp)
    val vBar = Modifier.width(56.dp).clip(shape).background(Panel).border(1.dp, Line, shape).padding(vertical = 10.dp)
    if (vertical) {
        Column(
            Modifier.align(alignment).padding(pad).alpha(if (dragging) 0.35f else 1f)
                .onGloballyPositioned { barPos = it.positionInRoot() }.then(vBar),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) { items(true) }
    } else {
        Row(
            Modifier.align(alignment).padding(pad).alpha(if (dragging) 0.35f else 1f)
                .onGloballyPositioned { barPos = it.positionInRoot() }.then(hBar),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp),
        ) { items(true) }
    }

    if (dragging) {
        val target = nearestDock(pressAt + total, area)
        val ghostAt = Modifier.offset { IntOffset((barPos.x + total.x).roundToInt(), (barPos.y + total.y).roundToInt()) }
        Box(Modifier.fillMaxSize()) {
            Dock.values().forEach { d ->
                val (fx, fy) = anchor(d)
                val on = d == target
                Box(
                    Modifier
                        .offset { IntOffset((fx * area.width).roundToInt() - 14.dp.roundToPx(), (fy * area.height).roundToInt() - 14.dp.roundToPx()) }
                        .size(28.dp).clip(CircleShape)
                        .then(if (on) Modifier.background(AccentBrush) else Modifier.background(PanelHi))
                        .alpha(if (on) 1f else 0.7f)
                )
            }
            Text(
                "Drag to an edge or corner", color = TextMuted, fontSize = 14.sp,
                modifier = Modifier.align(Alignment.Center),
            )
            // The ghost: the same bar, following the finger.
            if (vertical) {
                Column(
                    ghostAt.then(vBar),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                ) { items(false) }
            } else {
                Row(
                    ghostAt.then(hBar),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                ) { items(false) }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun NavButton(
    icon: ImageVector,
    label: String,
    active: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
) {
    val haptic = LocalHapticFeedback.current
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(if (active) PanelHi else Color.Transparent)
            .combinedClickable(
                onClick = onClick,
                onLongClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); onLongClick() },
            ),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, label, tint = if (active) Accent else TextMuted, modifier = Modifier.size(24.dp)) }
}
