package com.drift.app.ui

import android.view.SurfaceView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.drift.app.InstagramViewModel
import com.drift.app.data.Feed
import com.drift.app.data.IgKind
import com.drift.app.data.IgMedia
import com.drift.app.data.allowed
import com.drift.app.ui.theme.Accent
import com.drift.app.ui.theme.Panel
import com.drift.app.ui.theme.TextMuted
import kotlinx.coroutines.delay

/** One long vertical feed of what [feed] has loaded: one row per post, carousels swipe sideways. Hold a post for its menu. */
@Composable
fun FeedList(
    vm: InstagramViewModel,
    feed: Feed,
    onHold: (IgMedia) -> Unit,
    onOpenBrowser: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val cfg = vm.settings
    val p = cfg.photos.value
    val r = cfg.reels.value
    val profilesCount = vm.state.profiles.size
    val loadedCount = remember(vm.version, feed) { vm.mediaFor(feed).size }
    var playing by remember { mutableStateOf<IgMedia?>(null) }    // the reel playing full-screen

    // One row per post, in the order the posts were loaded; a post's items in carousel order. Hidden types are left out.
    val posts = remember(vm.version, feed, p, r) {
        val byPost = LinkedHashMap<String, MutableList<IgMedia>>()
        vm.mediaFor(feed).filter { it.allowed(cfg) }.forEach { byPost.getOrPut(it.post) { mutableListOf() }.add(it) }
        byPost.values.map { list -> list.sortedBy { it.index } }
    }
    val list = rememberLazyListState()

    // When the last few posts are on screen, ask for more (the page underneath is scrolled so Instagram loads them).
    val nearEnd by remember {
        derivedStateOf {
            val info = list.layoutInfo
            val last = info.visibleItemsInfo.lastOrNull()?.index ?: -1
            info.totalItemsCount > 0 && last >= info.totalItemsCount - 6
        }
    }
    LaunchedEffect(nearEnd, posts.size) {
        if (nearEnd) {
            vm.loadMore()
            delay(1500)
        }
    }

    Box(modifier.fillMaxSize().background(Color.Black)) {
        if (posts.isEmpty()) {
            Column(
                Modifier.align(Alignment.Center).padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                val (text, showBrowser) = emptyMessage(feed, loadedCount > 0, profilesCount)
                Text(text, color = TextMuted, fontSize = 14.sp, textAlign = TextAlign.Center)
                if (showBrowser) {
                    Row(
                        Modifier.clip(RoundedCornerShape(14.dp)).background(Panel).clickable(onClick = onOpenBrowser)
                            .padding(horizontal = 16.dp, vertical = 11.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Icon(AppIcons.Globe, null, tint = Accent, modifier = Modifier.size(18.dp))
                        Text("Open browser", color = Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        } else {
            LazyColumn(
                state = list,
                contentPadding = PaddingValues(top = 0.dp, bottom = 96.dp),     // bottom: clear of the navbar
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                items(posts, key = { it.first().post }) { row -> PostRow(vm, row, onHold, onPlay = { playing = it }) }
            }
        }
        playing?.let { m -> ReelPlayer(m, onClose = { playing = null }) }
    }
}

/** What to say when a feed has nothing to show, and whether to offer the Browser button. */
private fun emptyMessage(feed: Feed, hiddenBySettings: Boolean, profiles: Int): Pair<String, Boolean> {
    if (hiddenBySettings) return "Everything loaded here is hidden by your Settings." to false
    return when (feed.kind) {
        Feed.Kind.HOME -> "Nothing yet from your home feed.\nIf you haven't signed in, do that in the Browser; the feed fills in as the page loads." to true
        Feed.Kind.ALL_PROFILES ->
            if (profiles == 0) "No saved profiles yet.\nHold a post, go to its profile and tap the save button, or add several in Settings." to false
            else "Loading your saved profiles…\nIf nothing shows up, check you're signed in." to true
        Feed.Kind.PROFILE -> "Nothing yet for @${feed.key}.\nIt loads in the background; if it stays empty, check you're signed in." to true
        Feed.Kind.SAVED_ALL -> "Nothing yet from your saved posts.\nIt loads in the background; make sure you're signed in." to true
        Feed.Kind.SAVED_GROUP -> "Nothing yet from this group.\nIt loads in the background; make sure you're signed in." to true
    }
}

private class Loaded(val bmp: android.graphics.Bitmap?)

/** A post: one full-width item, or a carousel that swipes sideways (all cropped to the first item's shape). */
@Composable
private fun PostRow(vm: InstagramViewModel, items: List<IgMedia>, onHold: (IgMedia) -> Unit, onPlay: (IgMedia) -> Unit) {
    val first = items.first()
    val ratio = (first.w.toFloat() / first.h.coerceAtLeast(1)).coerceIn(0.4f, 2.5f)
    if (items.size == 1) {
        MediaTile(vm, first, ratio, null, onHold, onPlay, Modifier.fillMaxWidth())
    } else {
        val pager = rememberPagerState { items.size }
        HorizontalPager(
            state = pager,
            pageSpacing = 8.dp,
            key = { items.getOrNull(it)?.id ?: it },
        ) { i ->
            MediaTile(vm, items[i], ratio, "${i + 1}/${items.size}", onHold, onPlay, Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun MediaTile(
    vm: InstagramViewModel,
    m: IgMedia,
    ratio: Float,
    badge: String?,
    onHold: (IgMedia) -> Unit,
    onPlay: (IgMedia) -> Unit,
    modifier: Modifier,
) {
    val loaded by produceState<Loaded?>(initialValue = null, m.url) {
        value = Loaded(vm.loadBitmap(m.url, 1080))
    }
    val haptic = LocalHapticFeedback.current
    Box(
        modifier
            .aspectRatio(ratio)
            .background(Panel)
            .pointerInput(m.id) {
                detectTapGestures(
                    onTap = { if (m.kind == IgKind.REEL && m.videoUrl.isNotEmpty()) onPlay(m) },
                    onLongPress = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        onHold(m)
                    },
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        val bmp = loaded?.bmp
        when {
            loaded == null -> CircularProgressIndicator(color = TextMuted, modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
            bmp == null -> Text("Couldn't load", color = TextMuted, fontSize = 13.sp)
            else -> {
                val image = remember(bmp) { bmp.asImageBitmap() }
                Image(image, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            }
        }
        if (m.kind == IgKind.REEL) {
            Row(
                Modifier.align(Alignment.BottomStart).padding(10.dp)
                    .clip(RoundedCornerShape(10.dp)).background(Color(0x99000000))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Reel", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        if (badge != null) {
            Text(
                badge,
                color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(10.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0x99000000))
                    .padding(horizontal = 8.dp, vertical = 3.dp),
            )
        }
    }
}

/** A reel playing full-screen: it loops, the button at the bottom pauses or resumes it, X closes it. */
@Composable
fun ReelPlayer(m: IgMedia, onClose: () -> Unit) {
    val context = LocalContext.current
    val player = remember(m.videoUrl) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(m.videoUrl))
            repeatMode = Player.REPEAT_MODE_ONE
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    var playing by remember { mutableStateOf(true) }
    Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx -> SurfaceView(ctx).also { player.setVideoSurfaceView(it) } },
        )
        Box(
            Modifier.align(Alignment.TopEnd).padding(16.dp).size(40.dp)
                .clip(RoundedCornerShape(20.dp)).background(Color(0x99000000))
                .clickable(onClick = onClose),
            contentAlignment = Alignment.Center,
        ) {
            Icon(AppIcons.Close, "Close", tint = Color.White, modifier = Modifier.size(20.dp))
        }
        Text(
            if (playing) "Pause" else "Play",
            color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 48.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Color(0x99000000))
                .clickable {
                    playing = !playing
                    player.playWhenReady = playing
                }
                .padding(horizontal = 18.dp, vertical = 10.dp),
        )
    }
}
