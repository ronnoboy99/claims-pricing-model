package com.drift.app.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** One on/off setting, remembered between launches and observable from Compose. */
class Flag(private val prefs: SharedPreferences, private val key: String, default: Boolean) {
    var value by mutableStateOf(prefs.getBoolean(key, default))
        private set

    fun set(v: Boolean) {
        value = v
        prefs.edit().putBoolean(key, v).apply()
    }
}

/** Where the floating navbar sits. Bottom centre is the default (10dp from the bottom edge). */
enum class Dock { BOTTOM, BOTTOM_LEFT, BOTTOM_RIGHT, LEFT, RIGHT, TOP_LEFT, TOP_RIGHT, TOP }

/** What the feed shows and how the navbar behaves. */
class DriftSettings(context: Context) {
    private val prefs = context.getSharedPreferences("strip_settings", Context.MODE_PRIVATE)

    val photos = Flag(prefs, "photos", true)
    val reels = Flag(prefs, "reels", true)

    /** Leaves sponsored posts out of the feed. */
    val hideAds = Flag(prefs, "hide_ads", true)

    /** Which buttons the navbar has (the three dots are always there). */
    val showHome = Flag(prefs, "show_home", true)
    val showSaved = Flag(prefs, "show_saved", true)

    /** "Send to chat" in the hold menu. Off by default: with it off Drift never touches Instagram's messages. */
    val chat = Flag(prefs, "chat", false)

    var dock by mutableStateOf(
        runCatching { Dock.valueOf(prefs.getString("dock", Dock.BOTTOM.name)!!) }.getOrDefault(Dock.BOTTOM)
    )
        private set

    fun updateDock(d: Dock) {
        dock = d
        prefs.edit().putString("dock", d.name).apply()
    }
}

fun IgMedia.allowed(s: DriftSettings) = when (kind) {
    IgKind.PHOTO -> s.photos.value
    IgKind.REEL -> s.reels.value
}
