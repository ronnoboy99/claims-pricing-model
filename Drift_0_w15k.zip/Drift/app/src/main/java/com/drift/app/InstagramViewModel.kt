package com.drift.app

import android.annotation.SuppressLint
import android.app.Application
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.LruCache
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.webkit.UserAgentMetadata
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.drift.app.data.DriftSettings
import com.drift.app.data.Feed
import com.drift.app.data.IgCapture
import com.drift.app.data.IgImages
import com.drift.app.data.IgKind
import com.drift.app.data.IgMedia
import com.drift.app.data.InstagramStore
import com.drift.app.data.SavedGroup
import com.drift.app.data.parseInstagramProfile
import com.drift.app.data.shortcodeToPk
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File

const val IG_HOME = "https://www.instagram.com/"

/** The two navbar tabs. Each remembers its own source (see [Feed]). */
enum class Tab { HOME, SAVED }

enum class ProfileTab { POSTS, REELS, TAGGED, FOLLOWERS, FOLLOWING }

/** A profile opened from "Go to @name" (or from a name in a Followers / Following list). */
data class ProfileView(val user: String, val tab: ProfileTab = ProfileTab.POSTS)

/** One conversation in the Send sheet. */
data class ChatThread(val id: String, val title: String, val group: Boolean)

data class IgState(
    val profiles: List<String> = emptyList(),    // saved profiles
    val groups: List<SavedGroup> = emptyList(),  // Saved groups (Instagram collections)
    val tab: Tab = Tab.HOME,
    val homeFeed: Feed = Feed.Home,              // Home tab: Home, All profiles, or one saved profile
    val savedFeed: Feed = Feed.SavedAll,         // Saved tab: All posts, or one group
    val profileView: ProfileView? = null,
    val browser: Boolean = false,                // the in-app instagram.com is open (from Settings)
    val askUsername: Boolean = false,            // show the "what is your username?" prompt (Saved needs it)
    val error: String? = null,
    val notice: String? = null,                  // short message shown for a moment ("Saved", "Sent to 2")
)

/** The Instagram page the hidden browser is on, worked out from its address. Decides where captured posts go. */
private sealed interface Page {
    object Home : Page
    object SavedAll : Page
    data class SavedGroup(val id: String) : Page
    data class Profile(val user: String) : Page
    data class Tagged(val user: String) : Page
    data class Rel(val user: String, val kind: String) : Page      // kind: "followers" or "following"
    object Other : Page
}

/**
 * Instagram as a browser behind the scenes: a real WebView on the desktop instagram.com (login, profiles, scrolling all
 * work like the website). A small script watches what the page itself loads, and the photos and reels in it are kept
 * per page (home, each profile, saved, each saved group...). The feed you see is drawn by Drift from that data.
 *
 * Drift makes its own Instagram requests only when you ask for something: the list of Saved groups, Save post, and (when
 * Chat is on in Settings) your chat list and Send to chat. They run inside the page, so they use your login.
 */
class InstagramViewModel(app: Application) : AndroidViewModel(app) {

    private val ctx get() = getApplication<Application>().applicationContext
    private val store = InstagramStore(app)
    val settings = DriftSettings(app)
    private val main = Handler(Looper.getMainLooper())

    var state by mutableStateOf(
        IgState(
            profiles = store.profiles, groups = store.groups,
            homeFeed = store.homeFeed, savedFeed = store.savedFeed,
        )
    )
        private set

    /** Goes up whenever any loaded data changes; screens read it so they redraw. */
    var version by mutableStateOf(0)
        private set

    /** Conversations for the Send sheet: null until loaded. */
    var chats by mutableStateOf<List<ChatThread>?>(null)
        private set
    var chatsFailed by mutableStateOf(false)
        private set

    private val homeMap = LinkedHashMap<String, IgMedia>()
    private val savedMap = LinkedHashMap<String, IgMedia>()
    private val groupMaps = HashMap<String, LinkedHashMap<String, IgMedia>>()
    private val profileMaps = HashMap<String, LinkedHashMap<String, IgMedia>>()
    private val taggedMaps = HashMap<String, LinkedHashMap<String, IgMedia>>()
    private val relMaps = HashMap<String, LinkedHashSet<String>>()     // "followers:name" -> names
    private val avatars = HashMap<String, String>()                     // name -> profile picture url

    private val bitmaps = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 4).toInt()) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    private fun bump() { version++ }
    fun say(msg: String) { state = state.copy(notice = msg) }
    fun clearNotice() { state = state.copy(notice = null) }

    // ---------------- What is on screen ----------------

    /** The tab in use. If its button is switched off in Settings but the other one is on, the other one. */
    fun tabNow(): Tab {
        val t = state.tab
        return when {
            t == Tab.HOME && !settings.showHome.value && settings.showSaved.value -> Tab.SAVED
            t == Tab.SAVED && !settings.showSaved.value && settings.showHome.value -> Tab.HOME
            else -> t
        }
    }

    fun visibleFeed(): Feed = if (tabNow() == Tab.HOME) state.homeFeed else state.savedFeed

    fun mediaFor(feed: Feed): List<IgMedia> = when (feed.kind) {
        Feed.Kind.HOME -> homeMap.values.toList()
        Feed.Kind.SAVED_ALL -> savedMap.values.toList()
        Feed.Kind.SAVED_GROUP -> groupMaps[feed.key]?.values?.toList().orEmpty()
        Feed.Kind.PROFILE -> profileMaps[feed.key?.lowercase()]?.values?.toList().orEmpty()
        // Several profiles at once: newest first (posts with no date go last).
        Feed.Kind.ALL_PROFILES -> state.profiles
            .flatMap { profileMaps[it.lowercase()]?.values.orEmpty() }
            .sortedByDescending { it.ts }
    }

    fun profileMedia(user: String, tab: ProfileTab): List<IgMedia> = when (tab) {
        ProfileTab.POSTS -> profileMaps[user]?.values?.filter { it.kind == IgKind.PHOTO }.orEmpty()
        ProfileTab.REELS -> profileMaps[user]?.values?.filter { it.kind == IgKind.REEL }.orEmpty()
        ProfileTab.TAGGED -> taggedMaps[user]?.values?.toList().orEmpty()
        else -> emptyList()
    }

    fun relations(user: String, kind: String): List<String> = relMaps["$kind:$user"]?.toList().orEmpty()
    fun avatarUrl(user: String): String? = avatars[user.lowercase()]
    fun isSaved(post: String) = savedMap.values.any { it.post == post }
    fun isProfileSaved(name: String) = state.profiles.any { it.equals(name, ignoreCase = true) }

    // ---------------- The browser ----------------

    private var web: WebView? = null
    private var userAgent = ""
    val userAgentString: String get() = userAgent

    /** The page the browser is on, so a replacement browser can go back to it if Android kills the old one. */
    private var lastUrl: String? = null

    /** True while the feed (not the Browser) is showing: the hidden page then loads no pictures (Drift draws its own). */
    private var feedMode = true

    /** Goes up each time the browser is rebuilt; reading it in [browser] makes the screen pick up the new WebView. */
    private var browserEpoch by mutableStateOf(0)

    /** One WebView for the life of the app, so closing and reopening the Browser keeps the page and scroll position. */
    val browser: WebView
        get() {
            check(browserEpoch >= 0)   // read so Compose re-reads this after a rebuild
            return web ?: createBrowser().also { web = it }
        }

    private fun setFeedMode(on: Boolean) {
        feedMode = on
        web?.let(::applyFeedMode)
    }

    private fun applyFeedMode(w: WebView) {
        w.settings.blockNetworkImage = feedMode
        w.settings.mediaPlaybackRequiresUserGesture = feedMode
        w.evaluateJavascript("window.__driftSaver=$feedMode;" + if (feedMode) PAUSE_JS else "", null)
    }

    /** Android killed the browser's background process (low memory): drop the dead WebView and rebuild one on the same page. */
    private fun rebuildBrowser(dead: WebView) {
        val url = lastUrl ?: IG_HOME
        (dead.parent as? ViewGroup)?.removeView(dead)
        runCatching { dead.destroy() }
        if (web === dead) web = null
        browserEpoch++
        browser.loadUrl(url)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createBrowser(): WebView {
        val w = WebView(ctx)
        // Desktop Instagram: a desktop Chrome (Linux) user agent, and a wide page layout like "Desktop site" in Chrome.
        val chrome = Regex("Chrome/(\\d+)\\.(\\d+\\.\\d+\\.\\d+)").find(WebSettings.getDefaultUserAgent(ctx))
        val major = chrome?.groupValues?.get(1) ?: "131"
        val full = chrome?.let { "${it.groupValues[1]}.${it.groupValues[2]}" } ?: "131.0.0.0"
        userAgent = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/$major.0.0.0 Safari/537.36"
        w.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            userAgentString = userAgent
            useWideViewPort = true            // lay the page out ~980px wide, not phone width
            loadWithOverviewMode = true       // and fit that width to the screen at first
            setSupportZoom(true)              // pinch to zoom in
            builtInZoomControls = true
            displayZoomControls = false
        }
        applyFeedMode(w)
        // Tell the page (navigator.userAgentData) that this is not a mobile browser either.
        if (WebViewFeature.isFeatureSupported(WebViewFeature.USER_AGENT_METADATA)) {
            val brands = listOf(
                UserAgentMetadata.BrandVersion.Builder().setBrand("Chromium").setMajorVersion(major).setFullVersion(full).build(),
                UserAgentMetadata.BrandVersion.Builder().setBrand("Google Chrome").setMajorVersion(major).setFullVersion(full).build(),
            )
            WebSettingsCompat.setUserAgentMetadata(
                w.settings,
                UserAgentMetadata.Builder()
                    .setBrandVersionList(brands)
                    .setFullVersion(full)
                    .setPlatform("Linux")
                    .setPlatformVersion("6.5.0")
                    .setMobile(false)
                    .setArchitecture("x86")
                    .setBitness(64)
                    .build()
            )
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(w, true)
        }

        val origins = setOf("https://www.instagram.com")
        val docStart = WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER) &&
            WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)
        if (docStart) {
            WebViewCompat.addWebMessageListener(w, "DriftBridge", origins) { _, message, _, _, _ ->
                message.data?.let(::onCapture)
            }
            WebViewCompat.addDocumentStartJavaScript(w, HOOK_JS, origins)
        } else {
            w.addJavascriptInterface(object {
                @JavascriptInterface
                fun postMessage(s: String) { main.post { onCapture(s) } }
            }, "DriftBridge")
        }

        w.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                if (!docStart && url?.startsWith(IG_HOME) == true) view.evaluateJavascript(HOOK_JS, null)
                view.evaluateJavascript("window.__driftSaver=$feedMode;", null)
            }
            override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
                if (url != null) lastUrl = url
            }
            override fun onPageFinished(view: WebView, url: String?) {
                CookieManager.getInstance().flush()
                if (feedMode) view.evaluateJavascript(PAUSE_JS, null)
                when (val p = pageOf(url)) {
                    is Page.SavedAll -> { learnMe(url); refreshGroups() }
                    is Page.SavedGroup -> learnMe(url)
                    is Page.Rel -> scanRelations(p)
                    else -> {}
                }
            }
            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                rebuildBrowser(view)
                return true     // handled: without this the app would crash with the dead browser process
            }
        }
        return w
    }

    override fun onCleared() {
        web?.destroy()
        web = null
    }

    // ---------------- Pages ----------------

    private fun pageOf(url: String?): Page {
        val u = url ?: return Page.Other
        val uri = Uri.parse(u)
        if (uri.host?.endsWith("instagram.com") != true) return Page.Other
        val segs = uri.pathSegments
        if (segs.isEmpty()) return Page.Home
        val name = parseInstagramProfile(segs[0]) ?: return Page.Other     // posts, explore, login... are "other"
        return when (segs.getOrNull(1)) {
            "saved" -> {
                val id = segs.getOrNull(3)?.takeIf { s -> s.isNotEmpty() && s.all { it.isDigit() } }
                if (id != null) Page.SavedGroup(id) else Page.SavedAll
            }
            "tagged" -> Page.Tagged(name)
            "followers" -> Page.Rel(name, "followers")
            "following" -> Page.Rel(name, "following")
            else -> Page.Profile(name)      // the profile itself, and its posts and reels tabs
        }
    }

    private fun pageNow(): Page = pageOf(web?.url)

    /** /<you>/saved/... also tells us who "you" is. */
    private fun learnMe(url: String?) {
        val seg = Uri.parse(url ?: return).pathSegments.firstOrNull() ?: return
        parseInstagramProfile(seg)?.let { store.me = it }
    }

    private fun mapFor(p: Page): MutableMap<String, IgMedia>? = when (p) {
        Page.Home -> homeMap
        Page.SavedAll -> savedMap
        is Page.SavedGroup -> groupMaps.getOrPut(p.id) { LinkedHashMap() }
        is Page.Profile -> profileMaps.getOrPut(p.user) { LinkedHashMap() }
        is Page.Tagged -> taggedMaps.getOrPut(p.user) { LinkedHashMap() }
        else -> null
    }

    /** Where the browser should be for what is on screen (null for All profiles, which visits several pages). */
    private fun targetPage(): Page? {
        state.profileView?.let { pv ->
            return when (pv.tab) {
                ProfileTab.POSTS, ProfileTab.REELS -> Page.Profile(pv.user)
                ProfileTab.TAGGED -> Page.Tagged(pv.user)
                ProfileTab.FOLLOWERS -> Page.Rel(pv.user, "followers")
                ProfileTab.FOLLOWING -> Page.Rel(pv.user, "following")
            }
        }
        val f = visibleFeed()
        return when (f.kind) {
            Feed.Kind.HOME -> Page.Home
            Feed.Kind.PROFILE -> Page.Profile(f.key!!.lowercase())
            Feed.Kind.SAVED_ALL -> Page.SavedAll
            Feed.Kind.SAVED_GROUP -> Page.SavedGroup(f.key!!)
            Feed.Kind.ALL_PROFILES -> null
        }
    }

    private fun atTarget(): Boolean {
        val u = web?.url ?: return false
        val t = targetPage() ?: return false
        if (pageOf(u) != t) return false
        return state.profileView?.tab != ProfileTab.REELS || u.contains("/reels")
    }

    private fun hasData(t: Page): Boolean = when (t) {
        Page.Home -> homeMap.isNotEmpty()
        Page.SavedAll -> savedMap.isNotEmpty()
        is Page.SavedGroup -> groupMaps[t.id]?.isNotEmpty() == true
        is Page.Profile -> profileMaps[t.user]?.isNotEmpty() == true && state.profileView?.tab != ProfileTab.REELS
        is Page.Tagged -> taggedMaps[t.user]?.isNotEmpty() == true
        is Page.Rel -> relMaps["${t.kind}:${t.user}"]?.isNotEmpty() == true
        Page.Other -> true
    }

    private var lastNav = 0L

    private fun navigate(t: Page) {
        lastNav = System.currentTimeMillis()
        val reels = state.profileView?.tab == ProfileTab.REELS
        when (t) {
            Page.Home -> browser.loadUrl(IG_HOME)
            is Page.Profile -> browser.loadUrl("$IG_HOME${t.user}/" + if (reels) "reels/" else "")
            is Page.Tagged -> browser.loadUrl("$IG_HOME${t.user}/tagged/")
            is Page.Rel -> browser.loadUrl("$IG_HOME${t.user}/${t.kind}/")
            Page.SavedAll -> loadSaved(null)
            is Page.SavedGroup -> loadSaved(state.groups.firstOrNull { it.id == t.id })
            Page.Other -> {}
        }
    }

    /**
     * Make the hidden browser load what is on screen, if it isn't loaded yet. Called whenever the choice changes.
     * Data already loaded is kept and shown straight away; more is fetched when the feed nears its end ([loadMore]).
     */
    fun drive() {
        crawl?.cancel()
        if (state.browser) return
        if (state.profileView == null && visibleFeed().kind == Feed.Kind.ALL_PROFILES) { crawlRound(false); return }
        val t = targetPage() ?: return
        if (hasData(t)) return
        if (atTarget()) { if (t is Page.Rel) scanRelations(t); return }
        navigate(t)
    }

    /** The feed is about to run out: scroll the page underneath so Instagram loads more. */
    fun loadMore() {
        if (state.browser) return
        if (state.profileView == null && visibleFeed().kind == Feed.Kind.ALL_PROFILES) { crawlRound(true); return }
        val t = targetPage() ?: return
        if (atTarget()) scrollPage()
        else if (System.currentTimeMillis() - lastNav > 6000) navigate(t)
    }

    private fun scrollPage() {
        web?.evaluateJavascript("window.scrollTo(0, document.documentElement.scrollHeight);", null)
    }

    /**
     * All profiles: the hidden browser visits each saved profile in turn so every one has posts loaded. The first round
     * loads profiles that have nothing yet; later rounds ([scroll]) scroll each profile for its next batch.
     */
    private var crawl: Job? = null

    private fun allVisible() = !state.browser && state.profileView == null && visibleFeed().kind == Feed.Kind.ALL_PROFILES

    private fun crawlRound(scroll: Boolean) {
        if (crawl?.isActive == true) return
        crawl = viewModelScope.launch {
            for (name in state.profiles) {
                if (!allVisible()) return@launch
                val key = name.lowercase()
                if (!scroll && profileMaps[key]?.isNotEmpty() == true) continue
                val want = Page.Profile(key)
                if (pageNow() != want) {
                    lastNav = System.currentTimeMillis()
                    browser.loadUrl("$IG_HOME$key/")
                    var waited = 0
                    while (pageNow() != want && waited < 8000) { delay(250); waited += 250 }
                    delay(2500)
                }
                if (scroll) { scrollPage(); delay(2200) }
            }
        }
    }

    /** Followers / Following: the page shows them in a dialog; read the names from it while scrolling the list. */
    private var scan: Job? = null

    private fun scanRelations(p: Page.Rel) {
        scan?.cancel()
        scan = viewModelScope.launch {
            delay(2200)
            repeat(12) {
                if (pageNow() != p) return@launch
                web?.evaluateJavascript(SCRAPE_JS.replace("@KIND@", p.kind), null)
                delay(1400)
            }
        }
    }

    // ---------------- Tabs and choices ----------------

    fun selectTab(t: Tab) {
        state = state.copy(tab = t, profileView = null)
        drive()
    }

    fun pickHome(f: Feed) {
        store.homeFeed = f
        state = state.copy(tab = Tab.HOME, homeFeed = f, profileView = null)
        drive()
    }

    fun pickSaved(f: Feed) {
        store.savedFeed = f
        state = state.copy(tab = Tab.SAVED, savedFeed = f, profileView = null)
        drive()
        refreshGroups()
    }

    // ---------------- Profile views ----------------

    fun openProfileView(user: String) {
        val u = parseInstagramProfile(user) ?: return
        state = state.copy(profileView = ProfileView(u), browser = false)
        setFeedMode(true)
        drive()
    }

    fun closeProfileView() {
        state = state.copy(profileView = null)
        drive()
    }

    fun setProfileTab(t: ProfileTab) {
        val pv = state.profileView ?: return
        state = state.copy(profileView = pv.copy(tab = t))
        drive()
    }

    fun toggleProfileSaved(name: String) {
        val n = name.lowercase()
        if (isProfileSaved(n)) removeProfile(n) else {
            val list = listOf(n) + state.profiles
            store.profiles = list
            state = state.copy(profiles = list)
        }
    }

    // ---------------- Capturing what the page loads ----------------

    /** JSON the page loaded (or a message from one of Drift's own page scripts). */
    private fun onCapture(text: String) {
        when {
            text.startsWith("DRIFT_GROUPS:") -> onGroups(text.substring(13))
            text.startsWith("DRIFT_USERS:") -> onUsers(text.substring(12))
            text.startsWith("DRIFT_CHAT:") -> onChats(text.substring(11))
            text.startsWith("DRIFT_ACT:") -> onAct(text.substring(10))
            text.startsWith("DRIFT_SENT:") -> onSent(text.substring(11))
            text.startsWith("DRIFT_FAIL:") -> onFail(text.substring(11))
            else -> onMedia(text)
        }
    }

    private fun onMedia(text: String) {
        val p = pageNow()
        if (p === Page.Other || p is Page.Rel) return
        viewModelScope.launch {
            // On a profile only that profile's own posts count; home, saved and tagged show other people's posts.
            val only = (p as? Page.Profile)?.user
            val found = withContext(Dispatchers.Default) { IgCapture.parse(text, only, settings.hideAds.value) }
            if (p != pageNow()) return@launch            // the page changed while this was being read
            var changed = false
            found.avatars.forEach { (n, u) -> if (avatars[n] != u) { avatars[n] = u; changed = true } }
            val dest = mapFor(p)
            if (dest != null) found.media.forEach { m -> if (dest[m.id] != m) { dest[m.id] = m; changed = true } }
            if (changed) bump()
        }
    }

    private fun onUsers(body: String) {
        val kind = body.substringBefore(':')
        val p = pageNow()
        if (p !is Page.Rel || p.kind != kind) return
        val arr = runCatching { JSONArray(body.substringAfter(':')) }.getOrNull() ?: return
        val set = relMaps.getOrPut("$kind:${p.user}") { LinkedHashSet() }
        var changed = false
        for (i in 0 until arr.length()) {
            val n = parseInstagramProfile(arr.optString(i)) ?: continue
            if (n != p.user && set.add(n)) changed = true
        }
        if (changed) bump()
    }

    private fun onFail(what: String) {
        when (what) {
            "chat" -> { chatsFailed = true; chats = emptyList() }
        }
    }

    // ---------------- Saved groups ----------------

    /** Asks instagram.com (from inside the page, with your login) for your Saved groups. */
    fun refreshGroups() {
        val w = web ?: return
        if (w.url?.startsWith(IG_HOME) != true) return
        w.evaluateJavascript(GROUPS_JS, null)
    }

    private fun onGroups(json: String) {
        val a = runCatching { JSONArray(json) }.getOrNull() ?: return
        val list = List(a.length()) { i ->
            val o = a.getJSONObject(i)
            SavedGroup(o.optString("id"), o.optString("name").ifEmpty { "Group" })
        }.filter { it.id.isNotEmpty() }
        if (list == state.groups) return
        store.groups = list
        state = state.copy(groups = list)
        // A group that no longer exists falls back to All posts.
        val f = state.savedFeed
        if (f.kind == Feed.Kind.SAVED_GROUP && list.none { it.id == f.key }) pickSaved(Feed.SavedAll)
    }

    private fun slug(name: String) =
        name.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').ifEmpty { "group" }

    /** Open Saved (all posts, or one group). Needs your own username: remembered once known, else read from the page. */
    private fun loadSaved(group: SavedGroup?) {
        val b = browser
        fun go(name: String) {
            b.loadUrl(if (group == null) "$IG_HOME$name/saved/" else "$IG_HOME$name/saved/${slug(group.name)}/${group.id}/")
        }
        val me = store.me
        if (me != null) { go(me); return }
        b.evaluateJavascript(FIND_ME_JS) { raw ->
            val name = raw?.trim('"')?.takeIf { it.isNotEmpty() && it != "null" }?.let(::parseInstagramProfile)
            if (name != null) { store.me = name; go(name) } else state = state.copy(askUsername = true)
        }
    }

    fun dismissUsernamePrompt() { state = state.copy(askUsername = false) }

    /** The username the person typed into the prompt: remember it and open Saved. */
    fun saveMe(name: String) {
        val me = parseInstagramProfile(name) ?: return
        store.me = me
        state = state.copy(askUsername = false, error = null)
        drive()
    }

    // ---------------- The Browser (opened from Settings, or "Open in browser") ----------------

    fun openBrowser(url: String? = null) {
        crawl?.cancel()
        state = state.copy(browser = true, error = null)
        setFeedMode(false)
        if (url != null) browser.loadUrl(url) else if (browser.url == null) browser.loadUrl(IG_HOME)
    }

    fun closeBrowser() {
        state = state.copy(browser = false)
        setFeedMode(true)
        drive()
    }

    /** Go to a profile in the Browser (like typing it into the website). */
    fun browserGo(input: String) {
        val user = parseInstagramProfile(input)
        if (user == null) {
            state = state.copy(error = "That doesn't look like an Instagram profile name or link")
            return
        }
        state = state.copy(error = null)
        val target = "$IG_HOME$user/"
        if (browser.url?.startsWith(target) != true) browser.loadUrl(target)   // already there: don't reload
    }

    fun openInBrowser(m: IgMedia) {
        val kind = if (m.kind == IgKind.REEL) "reel" else "p"
        openBrowser("$IG_HOME$kind/${m.post.filter { it.isLetterOrDigit() || it == '-' || it == '_' }}/")
    }

    // ---------------- Hold menu actions ----------------

    private fun postItems(code: String): List<IgMedia> =
        (homeMap.values + savedMap.values + groupMaps.values.flatMap { it.values } +
            profileMaps.values.flatMap { it.values } + taggedMaps.values.flatMap { it.values })
            .filter { it.post == code }.distinctBy { it.id }

    /** A page on instagram.com to run Drift's own requests from, or null (with a message) if there isn't one. */
    private fun apiPage(): WebView? {
        val w = web
        if (w == null || w.url?.startsWith(IG_HOME) != true) {
            say("Open Instagram first (Settings → Browser)")
            return null
        }
        return w
    }

    /** Save post / Unsave post on Instagram (your Saved, All posts). */
    fun toggleSave(m: IgMedia) {
        val code = m.post.filter { it.isLetterOrDigit() || it == '-' || it == '_' }
        val pk = shortcodeToPk(code)
        if (pk == null) { say("Couldn't save this post"); return }
        val w = apiPage() ?: return
        val act = if (isSaved(m.post)) "unsave" else "save"
        w.evaluateJavascript(ACT_JS.replace("@PK@", pk).replace("@ACT@", act).replace("@CODE@", code), null)
    }

    private fun onAct(body: String) {
        val parts = body.split(':')
        if (parts.size < 3) return
        val act = parts[0]
        val code = parts[1]
        val result = parts[2]
        if (result != "ok") {
            val verb = if (act == "save") "save" else "unsave"
            say("Couldn't $verb ($result)")
            return
        }
        if (act == "save") {
            postItems(code).forEach { savedMap[it.id] = it }
            say("Saved")
        } else {
            savedMap.values.removeAll { it.post == code }
            groupMaps.values.forEach { g -> g.values.removeAll { it.post == code } }
            say("Removed from Saved")
        }
        bump()
    }

    /** Save the picture to Pictures/Drift on the phone. */
    fun saveToDevice(m: IgMedia) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    val bytes = IgImages.fetch(m.url, userAgent)
                    val name = "drift_${m.post}_${m.index}.jpg"
                    if (Build.VERSION.SDK_INT >= 29) {
                        val values = ContentValues().apply {
                            put(MediaStore.Images.Media.DISPLAY_NAME, name)
                            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Drift")
                            put(MediaStore.Images.Media.IS_PENDING, 1)
                        }
                        val resolver = ctx.contentResolver
                        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: error("no uri")
                        resolver.openOutputStream(uri)!!.use { it.write(bytes) }
                        values.clear()
                        values.put(MediaStore.Images.Media.IS_PENDING, 0)
                        resolver.update(uri, values, null, null)
                    } else {
                        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Drift")
                        dir.mkdirs()
                        File(dir, name).writeBytes(bytes)
                    }
                }.isSuccess
            }
            say(if (ok) "Saved to Pictures/Drift" else "Couldn't save the picture")
        }
    }

    // ---------------- Chat (only when switched on in Settings) ----------------

    /** Loads your recent conversations for the Send sheet. */
    fun loadChats() {
        if (!settings.chat.value) return
        val w = apiPage() ?: return
        chats = null
        chatsFailed = false
        w.evaluateJavascript(INBOX_JS, null)
    }

    private fun onChats(json: String) {
        val a = runCatching { JSONArray(json) }.getOrNull()
        if (a == null) { chatsFailed = true; chats = emptyList(); return }
        chatsFailed = false
        chats = List(a.length()) { i ->
            val o = a.getJSONObject(i)
            ChatThread(o.optString("id"), o.optString("title").ifEmpty { "Chat" }, o.optBoolean("group"))
        }.filter { it.id.isNotEmpty() }
    }

    /** Sends the post's link to each chosen conversation. */
    fun sendToChats(m: IgMedia, threadIds: List<String>) {
        if (!settings.chat.value || threadIds.isEmpty()) return
        val w = apiPage() ?: return
        val code = m.post.filter { it.isLetterOrDigit() || it == '-' || it == '_' }
        val kind = if (m.kind == IgKind.REEL) "reel" else "p"
        val ids = JSONArray(threadIds.map { id -> id.filter { it.isLetterOrDigit() || it == '_' || it == '-' } })
        w.evaluateJavascript(
            SEND_JS.replace("@LINK@", "$IG_HOME$kind/$code/").replace("@IDS@", ids.toString()), null
        )
    }

    private fun onSent(body: String) {
        val parts = body.split(':')
        val done = parts.getOrNull(0)?.toIntOrNull() ?: 0
        val total = parts.getOrNull(1)?.toIntOrNull() ?: 0
        val err = parts.getOrNull(2).orEmpty()
        say(
            when {
                total > 0 && done == total -> "Sent to $done"
                done > 0 -> "Sent to $done of $total"
                else -> "Couldn't send" + if (err.isNotEmpty()) " ($err)" else ""
            }
        )
    }

    // ---------------- Reset, sign out ----------------

    /** Empty what is on screen and load it again from the top. */
    fun resetFeed() {
        val pv = state.profileView
        if (pv != null) {
            profileMaps.remove(pv.user); taggedMaps.remove(pv.user)
            relMaps.keys.removeAll { it.endsWith(":${pv.user}") }
        } else {
            val f = visibleFeed()
            when (f.kind) {
                Feed.Kind.HOME -> homeMap.clear()
                Feed.Kind.ALL_PROFILES -> profileMaps.clear()
                Feed.Kind.PROFILE -> f.key?.let { profileMaps.remove(it.lowercase()) }
                Feed.Kind.SAVED_ALL -> savedMap.clear()
                Feed.Kind.SAVED_GROUP -> f.key?.let { groupMaps.remove(it) }
            }
        }
        bitmaps.evictAll()
        bump()
        if (targetPage() != null && atTarget()) web?.reload() else drive()
    }

    /**
     * Wipes the in-app browser (cookies, site storage, cache, history), forgets your username and Saved groups and
     * empties every feed, then opens Instagram's login in the Browser. Saved profiles are kept.
     */
    fun signOut() {
        crawl?.cancel(); scan?.cancel()
        homeMap.clear(); savedMap.clear(); groupMaps.clear(); profileMaps.clear(); taggedMaps.clear()
        relMaps.clear(); avatars.clear()
        bitmaps.evictAll()
        store.me = null
        store.groups = emptyList()
        chats = null
        state = state.copy(
            groups = emptyList(), profileView = null, askUsername = false, error = null,
            homeFeed = Feed.Home, savedFeed = Feed.SavedAll, browser = true,
        )
        store.homeFeed = Feed.Home
        store.savedFeed = Feed.SavedAll
        setFeedMode(false)
        bump()
        val b = browser
        b.stopLoading()
        WebStorage.getInstance().deleteAllData()
        b.clearCache(true)
        b.clearFormData()
        b.clearHistory()
        val cookies = CookieManager.getInstance()
        cookies.removeAllCookies {
            cookies.flush()
            main.post { b.loadUrl(IG_HOME) }
        }
    }

    // ---------------- Saved profiles ----------------

    /** Profile names found in pasted text: names or links separated by commas, spaces or new lines. No duplicates. */
    fun parseProfiles(text: String): List<String> =
        text.split(Regex("[\\s,;]+")).filter { it.isNotBlank() }
            .mapNotNull(::parseInstagramProfile)
            .distinctBy { it.lowercase() }

    /** Saves every new profile in [text] (ones you already have are skipped). Returns how many were added. */
    fun addProfiles(text: String): Int {
        val fresh = parseProfiles(text).filter { n -> state.profiles.none { it.equals(n, ignoreCase = true) } }
        if (fresh.isEmpty()) return 0
        val list = state.profiles + fresh
        store.profiles = list
        state = state.copy(profiles = list)
        return fresh.size
    }

    fun removeProfile(name: String) {
        val list = state.profiles.filter { !it.equals(name, ignoreCase = true) }
        store.profiles = list
        state = state.copy(profiles = list)
        val f = state.homeFeed
        if (f.kind == Feed.Kind.PROFILE && f.key.equals(name, ignoreCase = true)) pickHome(Feed.Home)
    }

    // ---------------- Images ----------------

    /** Downscaled bitmap (cached per size). Null if it can't be loaded. */
    suspend fun loadBitmap(url: String, targetW: Int): Bitmap? {
        val key = "$url@$targetW"
        bitmaps.get(key)?.let { return it }
        val ua = userAgent
        return withContext(Dispatchers.IO) {
            try {
                val bytes = IgImages.fetch(url, ua)
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                var sample = 1
                while (bounds.outWidth / (sample * 2) >= targetW) sample *= 2
                val bmp = BitmapFactory.decodeByteArray(
                    bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample }
                )
                if (bmp != null) bitmaps.put(key, bmp)
                bmp
            } catch (e: Exception) {
                null
            }
        }
    }

    private companion object {
        /** Pauses every video on the page (used while the feed shows; the hidden page should do nothing heavy). */
        const val PAUSE_JS = "document.querySelectorAll('video,audio').forEach(function (v) { try { v.pause(); } catch (e) {} });"

        /** Save / unsave a post. */
        const val ACT_JS = """
(function () {
  function post(s) { try { DriftBridge.postMessage(s); } catch (e) {} }
  if (!window.__driftApi) { post('DRIFT_ACT:@ACT@:@CODE@:error'); return; }
  window.__driftApi('/api/v1/web/save/@PK@/@ACT@/', '')
    .then(function (r) { post('DRIFT_ACT:@ACT@:@CODE@:' + (r.ok ? 'ok' : r.status)); })
    .catch(function () { post('DRIFT_ACT:@ACT@:@CODE@:error'); });
})();
"""

        /** Your Saved groups (collections), as [{id, name}]. */
        const val GROUPS_JS = """
(function () {
  function post(s) { try { DriftBridge.postMessage(s); } catch (e) {} }
  if (!window.__driftApi) { post('DRIFT_FAIL:groups'); return; }
  window.__driftApi('/api/v1/collections/list/?collection_types=%5B%22MEDIA%22%5D')
    .then(function (r) {
      if (!r.ok) throw r.status;
      var items = (JSON.parse(r.text).items || []).filter(function (c) {
        return c.collection_id && String(c.collection_type || '').indexOf('ALL_MEDIA') < 0;
      }).map(function (c) { return { id: String(c.collection_id), name: c.collection_name || '' }; });
      post('DRIFT_GROUPS:' + JSON.stringify(items));
    })
    .catch(function () { post('DRIFT_FAIL:groups'); });
})();
"""

        /** Recent conversations, as [{id, title, group}]. Only run when Chat is on. */
        const val INBOX_JS = """
(function () {
  function post(s) { try { DriftBridge.postMessage(s); } catch (e) {} }
  if (!window.__driftApi) { post('DRIFT_FAIL:chat'); return; }
  window.__driftApi('/api/v1/direct_v2/inbox/?persistentBadging=true&limit=20&thread_message_limit=1')
    .then(function (r) {
      if (!r.ok) throw r.status;
      var th = ((JSON.parse(r.text).inbox || {}).threads || []).map(function (t) {
        var names = (t.users || []).map(function (u) { return u.username; });
        return { id: String(t.thread_id), title: t.thread_title || names.join(', '), group: !!t.is_group };
      });
      post('DRIFT_CHAT:' + JSON.stringify(th));
    })
    .catch(function () { post('DRIFT_FAIL:chat'); });
})();
"""

        /** Sends a link to each conversation in turn, then reports "sent:total:lastError". */
        const val SEND_JS = """
(function (link, ids) {
  function post(s) { try { DriftBridge.postMessage(s); } catch (e) {} }
  if (!window.__driftApi) { post('DRIFT_SENT:0:' + ids.length + ':nopage'); return; }
  var done = 0, err = '', chain = Promise.resolve();
  ids.forEach(function (id) {
    chain = chain.then(function () {
      var ctx = String(Date.now()) + String(Math.floor(Math.random() * 1000));
      var body = 'action=send_item&link_text=' + encodeURIComponent(link) +
        '&link_urls=' + encodeURIComponent(JSON.stringify([link])) +
        '&thread_ids=' + encodeURIComponent(JSON.stringify([id])) +
        '&client_context=' + ctx + '&mutation_token=' + ctx + '&offline_threading_id=' + ctx;
      return window.__driftApi('/api/v1/direct_v2/threads/broadcast/link/', body)
        .then(function (r) { if (r.ok) done++; else err = String(r.status); });
    }).catch(function (e) { err = 'error'; });
  });
  chain.then(function () { post('DRIFT_SENT:' + done + ':' + ids.length + ':' + err); });
})('@LINK@', @IDS@);
"""

        /** On a followers / following page: read the names in the open dialog and scroll its list for more. */
        const val SCRAPE_JS = """
(function () {
  var d = document.querySelector('div[role="dialog"]');
  if (!d) return;
  var seen = {}, out = [];
  var as = d.querySelectorAll('a[href^="/"]');
  for (var i = 0; i < as.length; i++) {
    var m = (as[i].getAttribute('href') || '').match(/^\/([A-Za-z0-9._]{1,30})\/?$/);
    if (m && ['explore', 'reels', 'direct', 'accounts', 'p'].indexOf(m[1]) < 0 && !seen[m[1]]) { seen[m[1]] = 1; out.push(m[1]); }
  }
  var all = d.querySelectorAll('div');
  for (var j = 0; j < all.length; j++) {
    var e = all[j];
    if (e.scrollHeight > e.clientHeight + 40 && /(auto|scroll)/.test(getComputedStyle(e).overflowY)) { e.scrollTop = e.scrollHeight; break; }
  }
  try { DriftBridge.postMessage('DRIFT_USERS:@KIND@:' + JSON.stringify(out)); } catch (e) {}
})();
"""

        /** Finds your own username on a signed-in page: the "Profile" link of the side menu. Returns "" if not found. */
        const val FIND_ME_JS = """
(function () {
  function name(a) {
    var m = (a.getAttribute('href') || '').match(/^\/([A-Za-z0-9._]{1,30})\/?$/);
    return m && ['explore', 'reels', 'direct', 'accounts'].indexOf(m[1]) < 0 ? m[1] : '';
  }
  var as = document.querySelectorAll('a[href^="/"]');
  for (var i = 0; i < as.length; i++) {
    var l = ((as[i].getAttribute('aria-label') || '') + ' ' + (as[i].innerText || '')).trim();
    if (/^profile$/i.test(l) && name(as[i])) return name(as[i]);
  }
  var nav = document.querySelectorAll('nav a[href^="/"], [role="navigation"] a[href^="/"]');
  for (var j = 0; j < nav.length; j++) {
    var img = nav[j].querySelector('img');
    if (img && /profile picture/i.test(img.getAttribute('alt') || '') && name(nav[j])) return name(nav[j]);
  }
  return '';
})()
"""

        /** Runs inside instagram.com pages: passes on JSON that contains pictures, and defines Drift's own request helper. */
        const val HOOK_JS = """
(function () {
  if (window.__driftHooked) return;
  window.__driftHooked = true;
  var op = HTMLMediaElement.prototype.play;
  if (op) {
    HTMLMediaElement.prototype.play = function () {
      if (window.__driftSaver) { try { this.pause(); } catch (e) {} return Promise.resolve(); }
      return op.apply(this, arguments);
    };
  }
  function send(t) {
    try {
      if (t && t.length > 50 && (t.indexOf('image_versions2') > -1 || t.indexOf('video_versions') > -1 || t.indexOf('display_url') > -1 || t.indexOf('profile_pic_url') > -1)) {
        DriftBridge.postMessage(t);
      }
    } catch (e) {}
  }
  var of = window.fetch;
  window.__driftFetch = of;     // the untouched fetch: Drift's own requests use it so their answers are not read as page data
  if (of) {
    window.fetch = function () {
      var p = of.apply(this, arguments);
      try { p.then(function (r) { try { r.clone().text().then(send); } catch (e) {} }); } catch (e) {}
      return p;
    };
  }
  // A request made from the page, with your login. No body = GET; a body (even '') = POST.
  window.__driftApi = function (path, form) {
    var f = window.__driftFetch || window.fetch;
    var c = document.cookie.match(/csrftoken=([^;]+)/);
    var h = { 'X-IG-App-ID': '936619743392459', 'X-ASBD-ID': '129477', 'X-Requested-With': 'XMLHttpRequest' };
    var o = { credentials: 'include', headers: h };
    if (form !== undefined) {
      o.method = 'POST';
      o.body = form;
      h['Content-Type'] = 'application/x-www-form-urlencoded';
      h['X-CSRFToken'] = c ? decodeURIComponent(c[1]) : '';
    }
    return f.call(window, path, o).then(function (r) {
      return r.text().then(function (t) { return { ok: r.ok, status: r.status, text: t }; });
    });
  };
  var os = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.send = function () {
    this.addEventListener('load', function () {
      try { if (this.responseType === '' || this.responseType === 'text') send(this.responseText); } catch (e) {}
    });
    return os.apply(this, arguments);
  };
  function scan() {
    var s = document.querySelectorAll('script[type="application/json"]');
    for (var i = 0; i < s.length; i++) {
      if (!s[i].__w) { s[i].__w = 1; send(s[i].textContent); }
    }
  }
  document.addEventListener('DOMContentLoaded', scan);
  window.addEventListener('load', scan);
  setInterval(scan, 2500);
})();
"""
    }
}
