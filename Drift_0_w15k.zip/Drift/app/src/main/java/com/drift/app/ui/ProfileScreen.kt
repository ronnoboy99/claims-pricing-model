package com.drift.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drift.app.InstagramViewModel
import com.drift.app.ProfileTab
import com.drift.app.ProfileView
import com.drift.app.data.IgMedia
import com.drift.app.ui.theme.Accent
import com.drift.app.ui.theme.Bg
import com.drift.app.ui.theme.IconBtn
import com.drift.app.ui.theme.Panel
import com.drift.app.ui.theme.PanelHi
import com.drift.app.ui.theme.TextMuted
import com.drift.app.ui.theme.TextPrimary
import kotlinx.coroutines.delay

/**
 * A profile, condensed: small avatar, @name and an icon-only Save profile button (no counts), then the tabs
 * Posts / Reels / Tagged / Followers / Following. Tap a picture to open that post in the Browser, hold it for the post menu.
 */
@Composable
fun ProfileScreen(vm: InstagramViewModel, pv: ProfileView, onHold: (IgMedia) -> Unit) {
    val saved = vm.isProfileSaved(pv.user)
    Column(Modifier.fillMaxSize().background(Bg).displayCutoutPadding().padding(top = 12.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Avatar(vm, pv.user, 32.dp)
            Text(
                "@${pv.user}", color = TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, modifier = Modifier.weight(1f),
            )
            Box(
                Modifier.size(40.dp).clip(CircleShape).background(if (saved) PanelHi else IconBtn)
                    .clickable { vm.toggleProfileSaved(pv.user) },
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    if (saved) AppIcons.Check else AppIcons.UserAdd,
                    if (saved) "Saved profile" else "Save profile",
                    tint = if (saved) Accent else TextPrimary, modifier = Modifier.size(20.dp),
                )
            }
        }
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            listOf(
                ProfileTab.POSTS to "Posts", ProfileTab.REELS to "Reels", ProfileTab.TAGGED to "Tagged",
                ProfileTab.FOLLOWERS to "Followers", ProfileTab.FOLLOWING to "Following",
            ).forEach { (tab, label) ->
                val on = tab == pv.tab
                Text(
                    label, color = if (on) Accent else TextMuted, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clip(RoundedCornerShape(18.dp)).background(if (on) PanelHi else Panel)
                        .clickable { vm.setProfileTab(tab) }.padding(horizontal = 14.dp, vertical = 9.dp),
                )
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth().padding(top = 6.dp)) {
            when (pv.tab) {
                ProfileTab.FOLLOWERS -> People(vm, pv, "followers")
                ProfileTab.FOLLOWING -> People(vm, pv, "following")
                else -> Grid(vm, pv, onHold)
            }
        }
    }
}

@Composable
private fun Grid(vm: InstagramViewModel, pv: ProfileView, onHold: (IgMedia) -> Unit) {
    // One tile per post (a carousel shows its first picture).
    val tiles = remember(vm.version, pv) { vm.profileMedia(pv.user, pv.tab).filter { it.index == 0 } }
    val grid = rememberLazyGridState()
    val nearEnd by remember {
        derivedStateOf {
            val info = grid.layoutInfo
            val last = info.visibleItemsInfo.lastOrNull()?.index ?: -1
            info.totalItemsCount > 0 && last >= info.totalItemsCount - 9
        }
    }
    LaunchedEffect(nearEnd, tiles.size) {
        if (nearEnd) {
            vm.loadMore()
            delay(1500)
        }
    }
    if (tiles.isEmpty()) {
        Empty("Nothing here yet.\nIt loads in the background; if it stays empty, check you're signed in.")
        return
    }
    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        state = grid,
        contentPadding = PaddingValues(bottom = 96.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        items(tiles.size, key = { tiles[it].id }) { i ->
            GridTile(vm, tiles[i], onTap = { vm.openInBrowser(tiles[i]) }, onHold = onHold)
        }
    }
}

@Composable
private fun GridTile(vm: InstagramViewModel, m: IgMedia, onTap: () -> Unit, onHold: (IgMedia) -> Unit) {
    val bmp by produceState<android.graphics.Bitmap?>(null, m.url) { value = vm.loadBitmap(m.url, 360) }
    val haptic = LocalHapticFeedback.current
    Box(
        Modifier.aspectRatio(1f).background(Panel).pointerInput(m.id) {
            detectTapGestures(
                onTap = { onTap() },
                onLongPress = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); onHold(m) },
            )
        },
    ) {
        val b = bmp
        if (b != null) {
            Image(remember(b) { b.asImageBitmap() }, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        }
    }
}

/** Followers or Following: names read from Instagram's own list (needs you signed in). Tap one to open that profile. */
@Composable
private fun People(vm: InstagramViewModel, pv: ProfileView, kind: String) {
    val names = remember(vm.version, pv) { vm.relations(pv.user, kind) }
    if (names.isEmpty()) {
        Empty("Loading the list…\nIt's read from Instagram's own ${kind} window; make sure you're signed in.")
        return
    }
    LazyColumn(contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 96.dp)) {
        items(names, key = { it }) { n ->
            Row(
                Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(14.dp))
                    .clickable { vm.openProfileView(n) }.padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Avatar(vm, n, 34.dp)
                Text("@$n", color = TextPrimary, fontSize = 15.sp, maxLines = 1, modifier = Modifier.weight(1f))
                Icon(AppIcons.Go, null, tint = TextMuted, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
private fun Empty(text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text, color = TextMuted, fontSize = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(32.dp))
    }
}
